#!C:\Users\N000184003\Desktop\project - nba\project - nba\nbaenv\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
