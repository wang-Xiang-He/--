============
Contributing
============

This project is unsupported. Please use https://github.com/anymail/django-anymail instead.
