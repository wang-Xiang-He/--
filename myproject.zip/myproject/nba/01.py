import  os
a = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+ '\\' + "static"+'\\' +"images"

print(a)